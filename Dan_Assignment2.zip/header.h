#define SERVER_TCP_PORT	7001	// default port
#define TRUE 		1
#define FALSE 		0
#define	RECORDTIME	10	// sleep timer on thread that loops the server status

